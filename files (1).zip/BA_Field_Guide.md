# THE BUSINESS ANALYST FIELD GUIDE
### A Start-to-Finish, Document-by-Document Training Manual — Built from Real Fintech/Payments Project Experience

**Who this is for:** A new Business Analyst (0 real-world project exposure) who understands BA theory but has never sat inside a live Agile/Waterfall payments project and produced the actual artifacts a BA is expected to produce.

**How to use this guide:** Read top to bottom, in order. Each phase builds on the last — exactly the way a real project unfolds. Every document type includes: *why it exists*, *who asks for it*, *how you actually build it*, *a filled-in sample*, and *what a new BA gets wrong*. Sequence diagrams show who talks to whom and in what order.

**Reference project used throughout:** A Payments Platform initiative at a fintech company — 4 modules (Onboarding, Settlement, Reconciliation, Payments), 13+ stakeholders across Engineering/Finance/UX/Risk-Compliance, 2 payment gateway integrations, Agile Scrum with a Waterfall governance layer (a very common "hybrid" setup in BFSI/Fintech — this is intentional, because most real fintech BA jobs are hybrid, not pure Agile).

---

## TABLE OF CONTENTS (Study Path — 35 Steps)

**PART A — Foundations**
1. What a Business Analyst Actually Does (Role, Not Title)
1a. The Real Skill Behind the Schedule: Managing Interruptions vs. Deep Work
2. The Project Lifecycle a BA Lives Inside (Waterfall vs Agile vs Hybrid)
3. The Full BA Tool Stack (What Each Tool Is Actually Used For)
4. Domain Primer: Payments, Settlement, Reconciliation, Fraud, KYC/AML

**PART B — Project Initiation**
5. Kickoff: How a BA Enters a New Project
5a. The Teams a BA Works With (Who Owns What, and How You Talk to Each)
6. Stakeholder Identification & the Stakeholder Register
7. RACI Matrix
8. Project Charter / SoW (Statement of Work)

**PART C — Elicitation & Current-State Analysis**
9. Requirements Elicitation Techniques (Workshops, Interviews, JAD)
10. AS-IS Process Mapping (BPMN)
11. Gap Analysis (AS-IS vs TO-BE)
12. Data Dictionary
13. Source-to-Target (S2T) Data Mapping
13a. Data Cleaning & Integrity Protocols

**PART D — Formal Requirements Documentation**
14. BRD (Business Requirements Document)
15. SRS (Software Requirements Specification)
16. FRD / FSD (Functional Requirements / Functional Specification Document)
16a. What a Complete, Audit-Ready FRD Includes
17. UML Diagrams a BA Draws (Use Case + Sequence Diagrams)
18. RTM (Requirements Traceability Matrix)

**PART E — Agile Execution Layer**
19. Epics — How a BA Actually Writes One
20. User Stories & BDD Acceptance Criteria
21. Backlog Grooming / Refinement (Step by Step)
22. MoSCoW Prioritization (and WSJF)
23. Sprint Planning, Stand-ups, Reviews, Retrospectives
23a. Definition of Ready (DoR) & Definition of Done (DoD)
24. Three Amigos Sessions

**PART F — Build, Test & Release**
25. BA's Role During Development (Query Handling, Change Impact)
26. UAT Planning
27. Writing UAT Test Cases (Full Worked Examples)
28. Defect Triage & Defect Reports
29. Regression / Smoke / Sanity Testing Coordination
30. Sign-off & Go-Live Checklist

**PART G — Post-Go-Live & Governance**
31. Hypercare & KPI Dashboards (Power BI)
31a. Continuous vs. Categorical Axis (A Configuration Detail That Actually Matters)
32. Change Request (CR) Management
33. Scenario Playbook — How a BA Handles 15 Real Situations

**PART H — Reference**
33a. How This Guide Maps to BABOK v3 (For CBAP/CCBA/ECBA Study)
34. Glossary of Every Term Used in This Guide
35. Self-Check: Am I Ready? (Checklist + How AI Tools Fit In, 2026)

**PART I — Applied**
36. Full Project Walkthrough: A Narrative Case Study, Week by Week ("Velocity Check" Fraud Module)

---

## How to Actually Study This Guide (Evidence-Based, Not Just "Read It")

Re-reading a section and feeling like it makes sense is **recognition**, not **recall** — and recognition is a poor predictor of whether you can actually produce the answer cold, in an interview or at your desk, three weeks from now. This guide is built around **active recall** and **spaced repetition**, the two techniques with the strongest evidence behind them for retaining technical material long-term.

**How the study aids in this guide work:**
- Every Part (A–I) ends with a **🔑 Key Takeaways** box (the 3–5 things worth remembering forever) and a **🧠 Active Recall Check** — a handful of one-fact questions with the answer hidden under a `Show answer` toggle.
- **The rule that makes this actually work:** don't peek. Force yourself to produce the answer from memory first — even a wrong attempt strengthens the memory more than reading the answer immediately does. Reading the answer without trying first creates the "illusion of competence" that makes people feel ready when they aren't.
- Each question tests **one atomic fact**, not a paragraph — if you catch yourself writing an essay to answer one, the question (or your answer) is too broad to be useful for recall practice.

**A realistic review schedule for this guide** (the spacing is what fights the natural "forgetting curve" — most new information is half-forgotten within a few days without deliberate review):

| When | What to Do |
|---|---|
| Day you first read a Part | Read it once, fully, then immediately attempt that Part's Active Recall Check before looking anything up |
| Day 3 after reading | Redo the same Part's recall check from memory, no notes |
| ~2 weeks later | Redo it again, mixed with 1–2 other Parts' recall checks in the same sitting (this "interleaving" is deliberately harder, and that difficulty is what makes it work) |
| ~1 month later | One final mixed pass across all 9 Parts' recall checks before considering yourself interview-ready |

**The Feynman check, for anything that still feels shaky:** try explaining the concept out loud, in plain language, to someone with zero BA background — the exact point where you get stuck or reach for jargon is the exact gap to go back and re-read.

---
# PART A — FOUNDATIONS

## 1. What a Business Analyst Actually Does (Role, Not Title)

Forget the textbook definition for a second. On a real fintech project, a BA is the **translation layer** sitting between three groups who do not naturally speak the same language:

| Group | Speaks in terms of | What they need from the BA |
|---|---|---|
| Business / Finance / Ops stakeholders | Revenue, SLA, compliance risk, customer complaints | A clear, written statement of "what we need" that they can sign off on without reading code |
| Engineering / Dev team | APIs, data models, edge cases, system constraints | Unambiguous, testable requirements they can build against without guessing |
| QA / UAT testers | Expected vs actual behaviour | A traceable list of "what must be true" so they know what "done" means |

A BA's day-to-day, concretely, on a project like this one looked like this:

- **Morning:** Check JIRA for new comments/blockers on stories you own → attend daily stand-up (2 minutes: what you did, what's blocking you, what's next) → answer 3–5 Slack/Teams queries from developers about a requirement ("what happens if the UPI ID is invalid — reject or retry?").
- **Mid-day:** Run or attend a requirements workshop / backlog grooming session → update a BRD/FRD based on stakeholder feedback → update the RTM.
- **Afternoon:** Write or review user stories and acceptance criteria for the next sprint → review a UAT defect and decide "is this a requirement gap or a build defect?" → update stakeholders via a status report.
- **Ongoing, every day:** You are the person everyone comes to when they are not sure "what was actually agreed." If you don't write it down, it didn't happen — that single sentence is the core discipline of the BA job.

**What a new BA gets wrong:** treating documentation as a formality done *after* a decision is made. In reality, the act of writing the BRD/FRD is *how* ambiguity gets discovered — you write it, a gap appears, you go back and ask, and only then is the decision actually made.

### 1a. The Real Skill Behind the Schedule: Managing Interruptions vs. Deep Work

The bullet list above shows *what* fills a BA's day — but the skill that actually separates a strong BA from a struggling one is *how* they handle the tension between two competing demands that never stop: being available for the constant stream of "quick questions" from developers, testers, and stakeholders, and protecting enough uninterrupted time to actually write a clear, complete BRD or FRD.

- **A BRD/FRD is not written in five-minute fragments.** The sustained thinking a good requirements document needs cannot happen between Slack pings — a BA who answers every message the instant it arrives will produce shallower documents, not faster ones.
- **The realistic fix is batching, not becoming unresponsive.** Set an expectation with your team ("non-urgent questions get answered by end of day; anything blocking a build gets answered within the hour") and hold a genuinely protected block — commonly late morning or afternoon — for writing.
- **This is also why backlog refinement is usually an afternoon activity**, not a first-thing-in-the-morning one: the morning tends to absorb the reactive load (stand-up, overnight queries, urgent blockers), leaving the afternoon for the more deliberate, preparation-heavy work refinement actually requires.
- **What a new BA gets wrong:** treating every incoming message as equally urgent. Reflexive availability feels helpful in the moment but is what causes BRDs/FRDs to slip — the actual highest-value thing a BA produces (a document three teams will build and test against) requires protected, not fragmented, attention.

---

## 2. The Project Lifecycle a BA Lives Inside (Waterfall vs Agile vs Hybrid)

Most learning material teaches Waterfall and Agile as separate, competing models. Real BFSI/Fintech projects (like the one this guide is built around) run **Hybrid**: Waterfall-style governance and sign-off (because Finance, Risk/Compliance and PCI-DSS/RBI audits require formally signed documents) layered on top of Agile Scrum delivery (because the actual build happens in 2-week sprints).

```
WATERFALL (Governance Layer — used for compliance, contracts, audit trail)
Requirements → Design → Build → Test → Deploy → Maintain
      |            |        |      |       |         |
      v            v        v      v       v         v
   BRD/SoW      FRD/FSD   (Dev)  UAT    Go-Live   Hypercare
      |____________|________|______|_______|_________|
                             |
                             v
      AGILE SCRUM (Delivery Layer — used for actual sprint execution)
      Epics → Backlog → Sprint Planning → Daily Stand-up →
      Sprint Review → Retro → (repeat every 2 weeks until BRD scope is delivered)
```

**The same hybrid model as a chart:**

```mermaid
flowchart TD
    A[Business Need Identified] --> B[BRD / SoW<br/>Waterfall Sign-off]
    B --> C[FRD / FSD<br/>Waterfall Sign-off]
    C --> D[Epic Created]
    D --> E[Backlog Grooming]
    E --> F[Sprint Planning]
    F --> G[Sprint Execution<br/>Daily Stand-ups]
    G --> H[Sprint Review + Retro]
    H -->|More stories remain| E
    H -->|Epic complete| I[UAT<br/>Waterfall Gate]
    I --> J[Go-Live<br/>Waterfall Gate]
    J --> K[Hypercare]
    style B fill:#e8d5f5
    style C fill:#e8d5f5
    style I fill:#e8d5f5
    style J fill:#e8d5f5
    style D fill:#d5e8f5
    style E fill:#d5e8f5
    style F fill:#d5e8f5
    style G fill:#d5e8f5
    style H fill:#d5e8f5
```
*(Purple = Waterfall governance gate, Blue = Agile delivery loop — the loop repeats until the Waterfall-gated document's full scope is delivered.)*

**How to know which mode you're in:** if the client/business needs a *signed contract-like document before money or resources are released* → that's the Waterfall layer (BRD, SoW, FRD). If the *team is actively building this sprint* → that's the Agile layer (Epics, Stories, Sprints). A single BA typically produces documents for **both** layers on the same project, often in the same week.

---

## 3. The Full BA Tool Stack (What Each Tool Is Actually Used For)

| Tool | What a BA actually uses it for |
|---|---|
| **JIRA** | Epics, user stories, sprint boards, backlog, defect tracking, linking stories to BRD/FRD line items |
| **Confluence** | Living home for BRD, FRD, RTM, meeting minutes, data dictionary — anything that needs version history and stakeholder comments |
| **MS Visio / Miro** | AS-IS/TO-BE process maps (BPMN), swimlane diagrams, wireframe sketches during workshops |
| **SQL (MySQL/PostgreSQL)** | Validating data assumptions before writing requirements ("how many transactions actually fail today?"), building the evidence behind a BRD's problem statement, validating UAT data setup |
| **Python (Pandas)** | Bulk data profiling/validation when SQL alone is too slow — e.g. reconciling 100,000+ transaction records to find the 3 recurring SLA-breach patterns |
| **Power BI (DAX, Power Query)** | KPI dashboards for go-live sign-off and hypercare monitoring — SLA %, defect trend, settlement accuracy |
| **Figma** | Reviewing UX wireframes against functional requirements — a BA doesn't design screens but validates them against the FRD |
| **Azure DevOps** | Same purpose as JIRA in Microsoft-stack shops — backlog, sprints, work item traceability |
| **Excel** | Quick RTMs, data mapping sheets, test case trackers for small-scope items |
| **Microsoft Copilot / GenAI tools (2026 norm)** | First-draft generation of user stories from a BRD paragraph, BDD acceptance criteria drafting, meeting-summary generation — the BA still owns accuracy and sign-off, AI just removes the blank-page problem |

**Rule of thumb:** JIRA/Azure DevOps = *what we're building this sprint*. Confluence/Visio = *what we agreed to build and why*. SQL/Python/Power BI = *the evidence and the proof it worked*.

---

## 4. Domain Primer: Payments, Settlement, Reconciliation, Fraud, KYC/AML

You cannot write a believable BRD for a payments module without knowing the domain vocabulary. Here is the minimum a BA needs:

- **Payment Gateway Integration:** the system that lets a customer's payment (UPI, card, NACH) reach the merchant/bank. A BA's job: define what happens on success, failure, timeout, and retry — these four states are almost always under-specified by business stakeholders and are exactly where FRDs must be precise.
- **UPI (Unified Payments Interface):** India's real-time payment rail. Key BA concern: transaction status can be "pending" for a window before settling — your requirements must define what the system shows the user *during* that window.
- **NACH (National Automated Clearing House):** used for recurring/bulk debits (EMIs, SIPs). Key BA concern: batch-based, not real-time — failure handling and retry cycles work completely differently from UPI.
- **Settlement:** the process of actually moving reconciled funds to the merchant's bank account, usually on a T+1/T+2 cycle. A BA writes settlement requirements around cut-off times, partial settlements, and exception holds.
- **Reconciliation:** matching what the gateway/bank says happened against what your internal ledger says happened. This is where a BA's SQL skills matter most — you'll often write the very query that surfaces a reconciliation break before it becomes a customer complaint.
- **Fraud Detection & Prevention:** rule-based or ML-based flagging of suspicious transactions. A BA defines the *business rules* (thresholds, velocity checks, blacklists) — the data science/engineering team implements the model.
- **KYC (Know Your Customer) / AML (Anti-Money Laundering):** onboarding checks required by regulation before a customer can transact. A BA's requirements here are unusually rigid because they map directly to RBI/regulatory clauses — every field and workflow step typically needs a citation back to the compliance policy it satisfies.
- **PCI-DSS:** the security standard for handling card data. As a BA you rarely design the security control itself, but you must know it exists so you never accidentally write a requirement asking to store raw card numbers or CVVs in a log or report.

---

### 🔑 Key Takeaways — Part A
- A BA is a translation layer between Business, Engineering, and QA — three groups that don't naturally speak the same language.
- Real fintech/BFSI projects run **Hybrid**: Waterfall governance (BRD/FRD sign-off, audit trail) layered on Agile Scrum delivery (sprints).
- "If you didn't write it down, it didn't happen" is the core discipline underneath every document in this guide.
- Compliance/Risk can override a delivery deadline in BFSI — this isn't a special case, it's the default.
- Reflexive availability to every incoming question is not the same as being helpful — protecting focus time is what actually gets a clear BRD/FRD written.

### 🧠 Active Recall Check — Part A
*(Answer from memory first — no peeking — then expand to check.)*

<details><summary>1. What are the three groups a BA translates between?</summary>Business/Finance/Ops, Engineering/Dev, and QA/UAT testers.</details>

<details><summary>2. In the hybrid model, which layer does the BRD/FRD sign-off belong to — Waterfall or Agile?</summary>Waterfall (the governance layer).</details>

<details><summary>3. Which tool is the "living home" for BRD/FRD/RTM with version history — JIRA or Confluence?</summary>Confluence.</details>

<details><summary>4. In payments, what are the four gateway states a BA must define behavior for?</summary>Success, failure, timeout, and retry.</details>

<details><summary>5. Why is backlog refinement usually scheduled in the afternoon rather than first thing in the morning?</summary>Mornings tend to absorb the reactive load (stand-up, overnight queries, urgent blockers); refinement needs more deliberate, prepared attention, which the afternoon better allows.</details>

---
# PART B — PROJECT INITIATION

## 5. Kickoff: How a BA Enters a New Project

```
SEQUENCE — Project Kickoff
Client Sponsor        Project Manager        Business Analyst        Tech Lead
     |                       |                       |                    |
     |--- Signs contract --->|                       |                    |
     |                       |--- Assigns BA -------->|                    |
     |                       |                       |--- Requests intro
     |                       |                       |    meeting w/ Sponsor
     |<---------------------------------------------- |                    |
     |--- Explains business problem (high level) ---->|                    |
     |                       |                       |--- Drafts Stakeholder
     |                       |                       |    Register + RACI  |
     |                       |                       |--- Shares with PM ->|
     |                       |<---------------------- |                    |
     |                       |--- Approves ---------->|                    |
     |                       |                       |--- Schedules elicitation
     |                       |                       |    workshops w/ every
     |                       |                       |    stakeholder in register
```

The very first thing a BA produces on a new engagement is **not** the BRD. It's the **Stakeholder Register**, because you cannot elicit requirements correctly until you know whose requirements actually count, and in what priority.

---

## 5a. The Teams a BA Works With (Who Owns What, and How You Talk to Each)

Before the Stakeholder Register (which is about *individuals*), you need the bigger map: which *teams/departments* exist on a real fintech/payments organization, what each one actually owns, what they need from you, and what you need from them. Industry structure guides consistently group fintech/payments companies into five to seven core functions — Product, Engineering/Technology, Risk & Compliance, Finance & Operations, and Data/Analytics as the core five, with QA usually embedded inside Engineering and a separate Financial Partnerships/Vendor Management function appearing once a company scales. A BA sits at the intersection of nearly all of them, which is exactly why the role exists.

| Team / Department (industry-standard name) | What they own | What they need from the BA | What the BA needs from them | Typical friction point |
|---|---|---|---|---|
| **Product Management** | Prioritization, roadmap, final scope decisions, business value calls (led by a CPO/VP Product) | Clear options with trade-offs, not just problems | A fast, final decision when priorities conflict | PO changes priority mid-sprint without realizing the downstream impact — BA's job is to make that impact visible via Change Impact Analysis |
| **Finance & Operations** | Budget, ROI justification, settlement/reconciliation rules, day-to-day process operations (often reports to a CFO/COO) | Business Case with quantified savings/cost; rule definitions in plain language; clear definition of what changes in their daily workflow | Sign-off on any requirement touching money movement or reporting; ground-truth on how the AS-IS process actually works | Finance/Ops thinks in monthly/quarterly cycles while Agile sprints move faster — BA translates sprint progress into a cadence they can track |
| **Risk & Compliance** | Regulatory adherence (RBI, PCI-DSS, KYC/AML, SOX/PSD2 abroad), fraud policy, audit trail — often organized around compliance, risk, financial-partnerships and vendor-management sub-areas at scale | Every requirement touching money, identity, or fraud flagged for their review *before* build starts, not after | Explicit sign-off, in writing, on Must-Have compliance rules | Compliance review often takes longer than a sprint — BA has to sequence FRD sections so compliance-heavy pieces go to review earliest |
| **Engineering / Technology** | Technical feasibility, architecture, the actual build; QA/testing is frequently a function inside this same department rather than fully separate | Unambiguous, testable requirements (FRD, acceptance criteria); fast answers to clarification queries | Realistic effort estimates; early flags if something is technically infeasible as written | Devs want detail depth up front; business wants speed — the FRD is the negotiated middle ground |
| **QA / Testing (within Engineering)** | Test strategy, defect detection, regression and compliance-test coverage | Requirements detailed enough to derive test cases from | Defect data to distinguish "build bug" from "requirement gap" during triage | Fintech QA increasingly must trace every test case back to a specific regulatory control, not just a functional requirement — the RTM is what makes that traceable |
| **Data & Analytics** | Data pipelines, reporting infrastructure, model/insight development — an increasingly critical, fast-growing function in fintech orgs | Clear definition of what data/metric a new requirement actually needs to produce | Confirmation that required data even exists and at what granularity, before you finalize a requirement | A dashboard requirement gets written before checking whether the underlying data is even captured — always validate against the Data Dictionary first |
| **UX / Design** (usually inside Product) | Interface design, usability | Functional requirements for any screen (what data must display, what actions are possible) | Wireframes/prototypes to validate against the FRD before build | UX designs something visually clean that quietly omits a required field — caught by reviewing designs against the FRD, not just "does it look good" |
| **InfoSec / Security** (often part of Engineering, sometimes standalone) | Data security, encryption, access control, PCI-DSS technical controls | Awareness of any requirement that stores, transmits, or displays sensitive data (card numbers, KYC documents) | Confirmation that a requirement doesn't violate a security control (e.g., never log raw card data) | A well-meaning reporting requirement asks for a field that Security won't allow to be stored in plain form — caught earlier by looping Security in during FRD review, not after build |

**A note on scope:** a BA rarely interacts directly with Sales & Marketing or Legal on delivery work — they sit further from day-to-day requirements — but they matter to know exist, because a Legal team occasionally owns the final wording of a regulatory disclosure your FRD only specifies functionally, and Sales/Marketing sometimes originates the business need in the first place (e.g., "customers are asking for X" reaching you via a Product Manager, not directly).

**The one habit that makes all these relationships work:** always translate a request into the *receiving team's* language before sending it. A Risk & Compliance officer's "we need this compliant" becomes an FR clause with a specific rule and audit-log requirement for Engineering. A developer's "the API rate-limits at 100 req/sec" becomes a plain-language constraint ("large batch uploads may take longer than 5 minutes") for Finance. That translation, done constantly and correctly, is 80% of the actual BA job — everything else in this guide is the toolkit for doing that translation well.

---

## 6. Stakeholder Identification & the Stakeholder Register

**Purpose:** identify everyone who can approve, block, or is impacted by the solution — and how much influence/interest each one has, so you know who to prioritize in workshops.

**How a BA builds it:** start from the org chart + the PM's kickoff notes, then confirm/expand it in your first meeting by literally asking each stakeholder "who else should be in the room for this?" (snowball technique).

**Sample — Stakeholder Register (Payments Platform project):**

| ID | Stakeholder | Role | Department | Influence | Interest | Engagement Approach |
|---|---|---|---|---|---|---|
| SH-01 | Rajeev M. | Product Owner | Product | High | High | Weekly 1:1 + every workshop |
| SH-02 | Priya S. | Finance Lead | Finance | High | Medium | Bi-weekly review of settlement rules |
| SH-03 | Arjun K. | Risk & Compliance Officer | Risk/Compliance | High | High | Sign-off gate on every KYC/AML requirement |
| SH-04 | Dev Team Lead | Engineering | Engineering | Medium | High | Daily stand-up + FRD walkthroughs |
| SH-05 | UX Designer | Design | Product | Medium | Medium | Figma review sessions |
| SH-06 | QA Lead | Quality | Engineering | Medium | High | UAT planning sessions |
| SH-07 | Ops Manager | Settlement Ops | Operations | Low | High | Monthly status update |

**The same register as a Power/Interest chart** (this is what most workshops actually draw on a whiteboard to decide engagement frequency at a glance):

```mermaid
quadrantChart
    title Stakeholder Power / Interest Grid
    x-axis Low Interest --> High Interest
    y-axis Low Influence --> High Influence
    quadrant-1 Manage Closely
    quadrant-2 Keep Satisfied
    quadrant-3 Monitor
    quadrant-4 Keep Informed
    Rajeev (Product Owner): [0.9, 0.9]
    Priya (Finance Lead): [0.55, 0.85]
    Arjun (Risk/Compliance): [0.9, 0.85]
    Dev Team Lead: [0.85, 0.55]
    UX Designer: [0.5, 0.5]
    QA Lead: [0.85, 0.5]
    Ops Manager: [0.8, 0.2]
```
Anyone landing in **"Manage Closely"** (top-right) gets weekly touchpoints and a seat at every workshop; anyone in **"Monitor"** (bottom-left) gets a status email and nothing more — this chart is what stops a BA from over- or under-communicating with the wrong people.

**What a new BA gets wrong:** listing only the people who *asked* for the project. Compliance/Risk officers rarely initiate a payments project but can single-handedly block go-live — they must always be in the register for any BFSI/fintech work, even if they never speak in the kickoff call.

---

## 7. RACI Matrix

**Purpose:** removes the single most common source of project delay — "I thought someone else was doing that." RACI = **R**esponsible (does the work), **A**ccountable (owns the outcome, only one person per row), **C**onsulted (gives input before), **I**nformed (told after).

**Sample — RACI for FRD sign-off, Payments module:**

| Activity | BA | Product Owner | Dev Lead | Risk/Compliance | QA Lead |
|---|---|---|---|---|---|
| Draft FRD | R | C | C | C | I |
| Review FRD | C | A | R | R | C |
| Approve FRD for build | I | A | C | R | I |
| Sign-off UAT | R | A | I | C | R |

**What a new BA gets wrong:** giving multiple people "A" on the same row. If two people are Accountable, in practice zero people are Accountable — this is the single most-checked mistake in any RACI review.

---

## 8. Project Charter / SoW (Statement of Work)

**Purpose:** the founding contract-like document — scope, objectives, timeline, budget boundary, and (critically) what is explicitly **out of scope**. This is what prevents scope creep later, because you can point back to a signed sentence.

**Sample — SoW excerpt (Payments Platform):**

> **Project:** Payments Platform Modernization — Phase 1
> **Objective:** Reduce transaction processing SLA breaches by improving settlement and reconciliation workflows across 2 payment gateway integrations.
> **In Scope:** Onboarding module enhancements, Settlement rule engine updates, Reconciliation dashboard, integration with Gateway A and Gateway B.
> **Out of Scope:** Fraud model redevelopment (tracked as a separate initiative), mobile app UI changes, NACH batch processing (Phase 2).
> **Timeline:** 6 months, delivered across 12 two-week sprints.
> **Acceptance Criteria for Project Closure:** Zero critical defects at go-live; 350+ UAT test cases signed off; KPI dashboard live in Power BI.

**What a new BA gets wrong:** leaving "Out of Scope" vague or blank. A missing out-of-scope list is the #1 cause of mid-project disputes ("but I assumed this was included") — always write it explicitly, even if it feels obvious.

---

### 🔑 Key Takeaways — Part B
- The first document a BA produces is the **Stakeholder Register**, not the BRD — you can't elicit correctly without knowing whose input counts.
- A RACI must have exactly **one** "A" per row — two Accountable owners means zero real accountability.
- The SoW's "Out of Scope" section is what prevents scope-creep disputes later — never leave it vague or blank.
- Risk/Compliance officers rarely *initiate* a payments project but can single-handedly *block* go-live — always in the register.

### 🧠 Active Recall Check — Part B
<details><summary>1. What's the very first artifact a BA produces on a new engagement?</summary>The Stakeholder Register.</details>

<details><summary>2. In RACI, how many people should be "Accountable" on a single row?</summary>Exactly one.</details>

<details><summary>3. What quadrant of the Power/Interest grid gets weekly touchpoints and a seat at every workshop?</summary>"Manage Closely" (high influence, high interest).</details>

<details><summary>4. What's the #1 cause of mid-project scope disputes, according to this guide?</summary>A missing or vague "Out of Scope" section in the SoW.</details>

---
# PART C — ELICITATION & CURRENT-STATE ANALYSIS

## 9. Requirements Elicitation Techniques (Workshops, Interviews, JAD)

A BA never "assumes" a requirement — it is always **elicited** using a technique appropriate to the situation:

| Technique | When a BA uses it | How it plays out on this project |
|---|---|---|
| **1:1 Stakeholder Interviews** | Early stage, sensitive/political topics, or a single decision-maker | 45-min call with the Risk/Compliance officer to understand AML thresholds no one else fully knows |
| **Requirements Workshops (JAD sessions)** | Cross-functional decisions needing multiple people in the room at once | The 20+ multi-stakeholder workshops across Onboarding/Settlement/Reconciliation/Payments — Engineering, Finance and UX debate a rule live and the BA captures the agreed version on screen |
| **Document Analysis** | Understanding an existing system before proposing changes | Reading old SOPs, legacy FRDs, and support tickets to understand *why* the current settlement process breaks under load |
| **Observation (Job Shadowing)** | Understanding a manual process no one has documented | Sitting with the Settlement Ops team for a day to see how they manually resolve a reconciliation break today |
| **Prototyping / Wireframe Walkthroughs** | Validating UX assumptions before writing the FRD | Reviewing a Figma prototype with the UX designer and Product Owner, capturing every "wait, that's not right" as a requirement change |
| **Surveys/Questionnaires** | Large stakeholder groups, low time-per-person | Rare in payments BA work but used when validating an internal reporting need across 15+ Finance/Ops stakeholders |

**Workshop facilitation checklist a BA follows every time:**
1. Send agenda + pre-read (existing BRD draft) 24–48 hrs ahead.
2. Open by restating the objective and what decision needs to be made by the end.
3. Capture live on a shared screen (Confluence page or Miro board) — never "I'll write it up later," because that's where disagreements get papered over.
4. Close by reading back the decisions and assigning owners for open items.
5. Send meeting minutes within the same day, with a due date for anyone who needs to object.

**What a new BA gets wrong:** running a workshop without a specific decision to reach. "Let's discuss settlement rules" produces two hours of talk and nothing written down. "We need to decide: does a partial settlement trigger an automatic retry or a manual hold?" produces a decision.

---

## 10. AS-IS Process Mapping (BPMN)

**Purpose:** document the *current* process exactly as it happens today — including the messy manual workarounds — before proposing any change. You cannot design a TO-BE state credibly without first proving you understand the AS-IS state.

**Sample — AS-IS Settlement Process (simplified BPMN-style swimlane, text form):**

```
LANE: Payment Gateway        LANE: Settlement Engine        LANE: Ops Team (Manual)
      |                              |                              |
[Txn Received] --------------> [Match to Ledger?] 
                                      |--YES--> [Auto-Settle] --> [Done]
                                      |--NO---> [Flag as Break] -----> [Ops manually
                                                                        investigates
                                                                        in Excel]
                                                                            |
                                                                    [Manually corrects
                                                                     ledger, re-runs] 
                                                                            |
                                                                    [2-day average
                                                                     resolution time]
```

The manual "Ops investigates in Excel" step, taking 2 days on average, is exactly the pain point a Gap Analysis will later target.

**What a new BA gets wrong:** drawing the AS-IS process the way it's *supposed* to work on paper, instead of the way it actually happens (including the workaround steps nobody officially documented). Always validate the diagram with the people who do the work, not just their manager.

---

## 11. Gap Analysis (AS-IS vs TO-BE)

**Purpose:** formally state the difference between current and desired state, across People, Process, Technology, and Data — this becomes the backbone of the BRD's "Business Need" section.

**Sample — Gap Analysis (Settlement module):**

| Dimension | AS-IS | TO-BE | Gap / Impact |
|---|---|---|---|
| Process | Manual Excel-based break investigation, ~2-day resolution | Automated reconciliation engine flags and auto-resolves 70% of common breaks | 25% SLA improvement target |
| Technology | No real-time dashboard; Ops checks status via email | Power BI dashboard with live settlement/reconciliation KPI tracking | New dashboard build required |
| Data | Ledger and gateway data reconciled once daily (batch) | Near-real-time matching every 15 minutes | New scheduled job + data pipeline needed |
| People | Ops team manually triages every break | Ops team only handles the 30% of breaks the engine can't auto-resolve | Reduced Ops workload; retraining on new exception queue |

**What a new BA gets wrong:** writing the TO-BE column as a wish list without tying every row back to a measurable business driver (SLA %, error rate, hours saved). Auditors and Finance sponsors will ask "how do we know this gap matters?" — the Gap Analysis is where you answer that in advance.

**The AS-IS vs TO-BE impact, as a chart:**

```mermaid
graph LR
    subgraph AS-IS
    A1[Manual Excel review<br/>~2-day resolution]
    end
    subgraph TO-BE
    B1[Automated engine<br/>auto-resolves 70% of breaks]
    end
    A1 -->|Gap: 25% SLA improvement target| B1
```

---

## 12. Data Dictionary

**Purpose:** a single source of truth for every field name, data type, format, and business meaning used across requirements documents — prevents "wait, is `txn_status` the same as `payment_status`?" arguments between Engineering and QA six weeks later.

**Sample — Data Dictionary excerpt:**

| Field Name | Data Type | Format/Length | Business Definition | Source System | Mandatory? |
|---|---|---|---|---|---|
| `txn_id` | String | 20 alphanumeric | Unique identifier generated at transaction initiation | Payment Gateway | Yes |
| `txn_status` | Enum | `PENDING`/`SUCCESS`/`FAILED`/`REVERSED` | Current lifecycle state of the transaction as reported by gateway | Payment Gateway | Yes |
| `settlement_date` | Date | YYYY-MM-DD | Date funds are credited to merchant account | Settlement Engine | Yes (post-settlement) |
| `recon_break_flag` | Boolean | TRUE/FALSE | Indicates ledger and gateway records do not match | Reconciliation Engine | Yes |
| `kyc_verified_flag` | Boolean | TRUE/FALSE | Confirms customer has passed KYC checks before onboarding completion | Onboarding Service | Yes |

**What a new BA gets wrong:** creating this once and never updating it as new fields get discovered mid-project. Treat it as a living document owned jointly by BA + Data/Engineering lead.

---

## 13. Source-to-Target (S2T) Data Mapping

**Purpose:** shows exactly how a field in the source system maps (and transforms) into a field in the target system — critical whenever data moves between two systems, e.g., Gateway → internal Ledger.

**Sample — S2T Mapping (Gateway A → Internal Ledger):**

| Source Field (Gateway A) | Source Format | Transformation Rule | Target Field (Ledger) | Target Format |
|---|---|---|---|---|
| `transactionRefNo` | 18-char string | Direct copy | `txn_id` | 20-char string (zero-padded) |
| `txnStatusCode` | Numeric (0/1/2/3) | 0→PENDING, 1→SUCCESS, 2→FAILED, 3→REVERSED | `txn_status` | Enum |
| `amountInPaise` | Integer (paise) | Divide by 100 | `amount_inr` | Decimal(10,2) |
| `custMobile` | 10-digit string | Mask last 4 digits before storing (PCI/privacy rule) | `masked_mobile` | String, 10 chars with mask |

**What a new BA gets wrong:** forgetting to specify the *transformation rule* and only mapping field-to-field. Engineers cannot build a mapping correctly from names alone — the transformation logic (unit conversion, code lookup, masking) is the actual content of this document.

### 13a. Data Cleaning & Integrity Protocols (Before You Build the Business Case)

Before any SQL/Python profiling result goes into a BRD's problem statement, a BA needs a defensible, auditable way of handling the messy records every real dataset has. A few protocols that actually hold up under audit:

- **Never silently delete anomalous records.** An invalid, zero-price, or duplicate transaction record should be moved to a dedicated **exception/review file**, not dropped from the working dataset — deleting it destroys the audit trail a compliance reviewer will later ask for ("show me what you excluded and why").
- **Logical/sequence errors get flagged and root-caused, not statistically patched.** If a settlement date is logged *before* its transaction date, that's a **data integrity defect**, not a normal outlier — the correct response is to quarantine the record, raise it with the source-system owner, and root-cause it (5-Why/Fishbone, Section 11's technique). Applying a statistical fix like a median or mean to "correct" an impossible date sequence would hide a real system defect behind a plausible-looking number — never do this to logically invalid data. (Median/mean imputation has a legitimate, narrow use case: filling a genuinely *missing* value in a continuous numeric field, such as an absent transaction amount — not repairing an internally contradictory date sequence.)
- **Always query against the real production table/schema**, not a cached extract, a renamed copy, or an old snapshot — a data dictionary or S2T mapping built against the wrong source silently drifts from reality the moment the real schema changes underneath it.

**What a new BA gets wrong:** treating a data-quality issue as something to quietly clean up before anyone notices, instead of something to document, quarantine, and escalate. The quarantine file itself often becomes an appendix to the BRD's problem statement — it's evidence, not a mess to hide.

---

### 🔑 Key Takeaways — Part C
- A BA never assumes a requirement — it's always elicited using a technique fit for the situation (workshop, interview, shadowing, document analysis).
- A workshop needs one specific decision to reach — "let's discuss X" produces talk, not a decision.
- AS-IS must document the process as it **actually** happens, including undocumented manual workarounds — not the idealized version.
- Every TO-BE row in a Gap Analysis must tie back to a measurable business driver (SLA %, error rate, hours saved), or it's just a wish list.
- A Data Dictionary is a *living* document, jointly owned by BA + Engineering — not a one-time deliverable.

### 🧠 Active Recall Check — Part C
<details><summary>1. Name one elicitation technique used for understanding a manual process nobody has documented.</summary>Observation / job shadowing.</details>

<details><summary>2. What must you validate an AS-IS diagram against — the manager's description, or the people who actually do the work?</summary>The people who actually do the work.</details>

<details><summary>3. What four dimensions does a Gap Analysis compare AS-IS vs TO-BE across?</summary>People, Process, Technology, and Data.</details>

<details><summary>4. In S2T mapping, what's the one thing new BAs forget to specify beyond field-to-field names?</summary>The transformation rule (unit conversion, code lookup, masking, etc.).</details>

---
# PART D — FORMAL REQUIREMENTS DOCUMENTATION

## 14. BRD (Business Requirements Document)

**Purpose:** states the business problem and *what* needs to change, in business language — deliberately says nothing about *how* it will be built. This is the document Finance/Risk/Product sign off on before Engineering starts detailed design.

**Standard BRD structure a BA follows:**
1. Executive Summary
2. Business Objectives (tied to measurable KPIs)
3. Scope (In / Out)
4. Stakeholders
5. Business Requirements (numbered, e.g., BR-01, BR-02...)
6. Assumptions & Constraints
7. Risks
8. Sign-off section (names + dates)

**Sample — BRD excerpt (Settlement Module):**

> **BR-01:** The system shall automatically flag any transaction where the gateway-reported status does not match the internal ledger status within 15 minutes of transaction completion.
> **Business Rationale:** Currently, reconciliation breaks are discovered once daily via manual batch review, causing an average 2-day resolution delay and contributing to 3 recurring SLA breach patterns identified in the Q3 transaction data analysis (100,000+ records reviewed via SQL/Python).
> **Priority:** Must Have
> **Owner:** Priya S. (Finance Lead)

**What a new BA gets wrong:** slipping technical/solution detail into a BRD ("the system shall use a Kafka queue to..."). That belongs in the FRD/design doc. A BRD that names a specific technology has jumped ahead of the business sign-off it's meant to protect.

---

## 15. SRS (Software Requirements Specification)

**Purpose:** a more formal, IEEE-style specification sometimes required in regulated/contract-driven engagements — bridges between the BRD (business language) and FRD (functional/system language), often required when a document must be handed to an external vendor or audited by a third party.

**Sample — SRS excerpt structure:**
- 1. Introduction (Purpose, Scope, Definitions)
- 2. Overall Description (Product perspective, user classes, constraints)
- 3. Specific Requirements (Functional, Non-Functional — performance, security, availability)
- 4. External Interface Requirements (APIs, UI, hardware if relevant)

> **Non-Functional Requirement Example:** The reconciliation engine shall process a batch of 100,000 transaction records within 10 minutes, with 99.9% uptime during business hours (9 AM–9 PM IST), and shall comply with PCI-DSS data-at-rest encryption standards.

**What a new BA gets wrong:** treating SRS and FRD as the same document, or assuming there's one universal sequence. SRS leans toward system-level, engineering-facing specification (often used in product/embedded/regulated contexts); FRD is the more common fintech-BA-owned document translating *business* requirements into *functional* system behaviour. **Important:** there is no single industry-wide standard for whether SRS comes before or after the FRD — practices genuinely differ by company, and even BABOK/IIBA does not mandate one fixed order. On many projects only one of BRD/SRS/FRD is actually produced at all. Always check what your specific client/PMO expects before assuming a sequence or drafting a document nobody asked for.

---

## 16. FRD / FSD (Functional Requirements / Functional Specification Document)

**Purpose:** the document Engineering actually builds against. Translates each BRD business requirement into precise, testable functional behaviour — including every edge case, error state, and business rule. This is the single most important document a fintech BA produces.

**Sample — FRD excerpt (traced from BR-01 above):**

> **FR-01.1:** Upon transaction completion, the system shall compare `txn_status` from the Payment Gateway against the corresponding ledger entry `txn_status` within a 15-minute polling window.
> **FR-01.2:** If a mismatch is found, the system shall set `recon_break_flag = TRUE` and create an exception record in the Ops Exception Queue with fields: `txn_id`, `gateway_status`, `ledger_status`, `flagged_timestamp`.
> **FR-01.3 (Error Handling):** If the Payment Gateway API does not respond within 5 seconds, the system shall retry twice at 10-second intervals before logging a `GATEWAY_TIMEOUT` error and notifying the on-call Ops engineer.
> **FR-01.4 (Business Rule):** Auto-resolution shall only be attempted for mismatches where the amount difference is ≤ ₹1 (rounding tolerance); all others route to manual Ops review.
> **Acceptance Criteria (BDD style):**
> ```
> GIVEN a transaction has completed at the Payment Gateway
> WHEN the ledger status differs from the gateway status after 15 minutes
> THEN the system flags a reconciliation break and creates an exception record
> ```

**What a new BA gets wrong:** writing FRDs that describe the "happy path" only. Real FRDs are 40–60% error-handling and edge-case rules (timeouts, partial data, invalid input, concurrent updates) — that's precisely the content developers and QA actually need, since the happy path rarely causes bugs.

### 16a. What a Complete, Audit-Ready FRD Includes

Beyond the functional workflow and business rules above, an FRD that will actually survive a client or compliance review names these components explicitly — don't leave any of them implicit:

- **UI Screen Workflows** — for any ops-facing screen (e.g., the Exception Queue dashboard), a screen-by-screen flow of what the user sees and does at each step, cross-referenced to the wireframe (Section 5a covers who owns the wireframe itself — UX — vs. who defines the workflow it must support — the BA).
- **Data Input Validation Rules** — every field a human or upstream system can populate needs an explicit rule: required/optional, format, range, and what happens on invalid input (reject, flag, auto-correct). "Amount must be positive" is not enough — "Amount must be a positive decimal with exactly 2 places; a negative or zero value is rejected at the API layer with error code `INVALID_AMOUNT`" is.
- **Non-Functional Requirements (Security/SLA)** — see the SRS example above; these belong in the FRD too when no separate SRS exists on your project.
- **Architecture Diagrams** — a BA references and validates against these, but does not author them; that's Engineering's deliverable (see Section 17's boundary on UML ownership).

**On acceptance criteria specifically:** the Given/When/Then format above is formally called **Gherkin syntax**, the industry-standard structure for BDD (Behaviour-Driven Development) scenarios. Writing acceptance criteria in strict Gherkin — not a loose paraphrase of it — is what lets QA translate them directly into automated test scripts without re-interpreting your intent.

---

## 17. UML Diagrams a BA Draws (Use Case + Sequence Diagrams)

A BA is not expected to design a full system architecture diagram — that's Engineering's job — but two UML diagram types are squarely a BA deliverable because they describe *business behaviour*, not internal code structure.

### 17a. Use Case Diagram

```
             (Onboard New Customer)
Customer  ------->    |
             (Submit KYC Documents)
                      |
             (System validates KYC) <--- «include» --- (Onboard New Customer)
                      |
Risk Officer ------> (Review Flagged KYC Case)
```

### 17b. Sequence Diagram — Reconciliation Break Flow (the same scenario as FR-01 above, shown as an interaction over time)

```
Customer      Payment Gateway      Settlement Engine      Ledger DB      Ops Exception Queue
   |                 |                     |                  |                  |
   |--Initiates txn->|                     |                  |                  |
   |                 |--Processes payment->|                  |                  |
   |                 |--Reports SUCCESS--->|                  |                  |
   |                 |                     |--Reads ledger---->|                  |
   |                 |                     |<--Ledger: PENDING-|                  |
   |                 |                     |--Mismatch found-->|                  |
   |                 |                     |--Flag recon_break-------------------->|
   |                 |                     |                  |     [Ops notified,
   |                 |                     |                  |      investigates]
```

**Same flow as a rendered Mermaid sequence diagram** (paste this into any Mermaid-compatible viewer, e.g. GitHub, Obsidian, Mermaid Live Editor):

```mermaid
sequenceDiagram
    participant C as Customer
    participant PG as Payment Gateway
    participant SE as Settlement Engine
    participant L as Ledger DB
    participant OQ as Ops Exception Queue
    C->>PG: Initiates transaction
    PG->>SE: Processes payment
    PG-->>SE: Reports status = SUCCESS
    SE->>L: Reads ledger status
    L-->>SE: Ledger status = PENDING
    SE->>SE: Compares gateway vs ledger status
    Note over SE: Mismatch detected
    SE->>OQ: Flag recon_break_flag = TRUE
    OQ-->>OQ: Ops notified, investigates
```

**Why this matters to a new BA:** the sequence diagram is what you actually bring INTO a requirements workshop when Engineering says "wait, who calls whom, and in what order?" It resolves ambiguity far faster than a paragraph of prose, and it becomes the visual backbone of the FRD.

**What a new BA gets wrong:** trying to draw a full technical sequence diagram with internal class/method calls. Keep it at the *system/actor* level — that's the BA's lane; internal implementation sequence diagrams belong to the tech design document.

---

## 18. RTM (Requirements Traceability Matrix)

**Purpose:** proves every business requirement was actually built and tested — the document an auditor or Compliance officer asks for at go-live to confirm nothing was silently dropped.

**Sample — RTM excerpt:**

| BR ID | Business Requirement | FR ID | User Story / JIRA ID | Test Case ID | UAT Status |
|---|---|---|---|---|---|
| BR-01 | Auto-flag reconciliation breaks within 15 min | FR-01.1–FR-01.4 | PAY-234 | TC-045, TC-046 | Passed |
| BR-02 | KYC verification must block onboarding until AML check clears | FR-02.1–FR-02.3 | ONB-112 | TC-078, TC-079, TC-080 | Passed |
| BR-03 | Settlement dashboard shall show real-time SLA % | FR-03.1 | RPT-055 | TC-101 | In Progress |

**How a BA builds and maintains it:** created right after the BRD/FRD are baselined, then updated continuously as stories are written and test cases executed — by go-live, every single row should read "Passed," or the gap must be explicitly flagged and risk-accepted by the Product Owner in writing.

**What a new BA gets wrong:** building the RTM once at the start and never touching it again. It's a living document — if it doesn't match JIRA and the UAT tracker on the day of go-live, it's worthless as an audit artifact.

---

### 🔑 Key Takeaways — Part D
- BRD = business language, *what* needs to change. FRD = functional/system language, *how* it must behave. Never mix the two.
- A BRD naming a specific technology has jumped ahead of the business sign-off it exists to protect.
- A real FRD is 40–60% error-handling and edge cases — the happy path rarely causes bugs.
- A BA's UML lane is system/actor-level sequence and use-case diagrams — not internal code/class diagrams.
- The RTM is a living document — if it doesn't match JIRA and the UAT tracker on go-live day, it's worthless as an audit artifact.

### 🧠 Active Recall Check — Part D
<details><summary>1. Which document says nothing about *how* something will be built — BRD or FRD?</summary>BRD.</details>

<details><summary>2. Roughly what percentage of a well-written FRD is error-handling/edge cases, not the happy path?</summary>40–60%.</details>

<details><summary>3. Is there one universal industry-standard order for BRD → SRS → FRD?</summary>No — practices differ by company and even BABOK doesn't mandate one fixed order.</details>

<details><summary>4. What does the RTM prove to an auditor at go-live?</summary>That every business requirement was actually built and tested — nothing was silently dropped.</details>

---
# PART E — AGILE EXECUTION LAYER

## 19. Epics — How a BA Actually Writes One

**Purpose:** an Epic is a large body of work that delivers one FRD-level capability, broken down over multiple sprints into user stories. The BA typically drafts the Epic directly from the BRD/FRD sections.

**Sample — Epic (JIRA-style):**

> **Epic: PAY-200 — Automated Reconciliation Break Detection**
> **Description:** As the Settlement Ops team, we need the system to automatically detect and flag reconciliation breaks between gateway and ledger data within 15 minutes, so that manual investigation time drops from 2 days to under 4 hours.
> **Linked BRD/FRD:** BR-01, FR-01.1–FR-01.4
> **Business Value:** 25% SLA improvement (per Gap Analysis)
> **Child Stories:** PAY-201 (poll gateway status), PAY-202 (compare vs ledger), PAY-203 (create exception record), PAY-204 (notify Ops queue), PAY-205 (auto-resolve ≤₹1 tolerance cases)
> **Definition of Done:** All 5 child stories delivered, RTM rows BR-01/FR-01.x marked Passed, KPI dashboard shows live break count.

**Step-by-step, how a BA actually creates this in JIRA:**
1. Open the relevant FRD section, identify the single cohesive capability it describes.
2. Create the Epic issue type; title it as an outcome, not a task ("Automated Reconciliation Break Detection," not "Build reconciliation code").
3. Write the description in the "As a ___, we need ___, so that ___" outcome format — this keeps it business-value-anchored, not implementation-anchored.
4. Link the Epic back to the BRD/FRD IDs in the description or a custom field, so the RTM stays traceable.
5. Do NOT write child stories yet in full detail — that happens in backlog grooming (next section), because story-level detail should emerge from a conversation with the dev team, not be dictated solo by the BA.

**What a new BA gets wrong:** writing an Epic so large it never finishes ("Rebuild the Settlement Module") or so small it's really just a story. A well-sized Epic should map to roughly 2–4 sprints of work and one FRD section — not the whole FRD, not one paragraph of it.

**The Epic → Story breakdown as a chart:**

```mermaid
graph TD
    Epic["Epic PAY-200<br/>Automated Reconciliation<br/>Break Detection"]
    Epic --> S1["PAY-201<br/>Poll gateway status"]
    Epic --> S2["PAY-202<br/>Compare vs ledger"]
    Epic --> S3["PAY-203<br/>Create exception record"]
    Epic --> S4["PAY-204<br/>Notify Ops queue"]
    Epic --> S5["PAY-205<br/>Auto-resolve ≤₹1 tolerance"]
    S1 --> RTM["RTM Row: BR-01 / FR-01.1–01.4"]
    S2 --> RTM
    S3 --> RTM
    S4 --> RTM
    S5 --> RTM
```

---

## 20. User Stories & BDD Acceptance Criteria

**Purpose:** the smallest unit of deliverable business value, written from the user's perspective, small enough to be completed in a single sprint.

**Sample — User Story (child of Epic PAY-200):**

> **Story: PAY-203 — Create Exception Record on Reconciliation Break**
> **As a** Settlement Ops analyst
> **I want** the system to automatically create an exception record when a reconciliation break is detected
> **So that** I can review and resolve mismatches without manually cross-checking spreadsheets
>
> **Acceptance Criteria (BDD/Gherkin format):**
> ```
> Scenario 1: Break detected within tolerance
> GIVEN a transaction has a gateway/ledger status mismatch
> AND the amount difference is ≤ ₹1
> WHEN the 15-minute polling window elapses
> THEN the system auto-resolves the transaction
> AND logs the resolution in the audit trail
>
> Scenario 2: Break detected outside tolerance
> GIVEN a transaction has a gateway/ledger status mismatch
> AND the amount difference is > ₹1
> WHEN the 15-minute polling window elapses
> THEN the system creates an exception record in the Ops queue
> AND flags recon_break_flag = TRUE
> ```
> **Story Points:** 5
> **Linked FR:** FR-01.2, FR-01.4

**What a new BA gets wrong:** writing acceptance criteria as vague prose ("the system should handle errors properly") instead of concrete Given/When/Then scenarios that QA can turn directly into test cases. If you can't picture the exact test case that would prove this criterion, it isn't specific enough yet.

---

## 21. Backlog Grooming / Refinement (Step by Step)

**Purpose:** keeps the product backlog "DEEP" — **D**etailed appropriately, **E**stimated, **E**mergent, **P**rioritized — so the team always has 1–2 sprints of ready, unambiguous work queued up. Current industry guidance (2026) increasingly calls this **backlog refinement** rather than "grooming," for the same practice.

**Step-by-step — how a BA runs/participates in a grooming session:**
1. **Pre-session prep (BA does this alone, beforehand):** review the raw backlog, remove clearly obsolete items, flag duplicate stories for merging, and pre-draft acceptance criteria for the top 10–15 items likely to be discussed.
2. **In-session — clarify:** for each story, the Product Owner/BA restates the "why," and the dev team asks clarifying questions live. The BA updates acceptance criteria on-screen in real time.
3. **In-session — split:** any story too large for one sprint gets split into smaller stories (e.g., PAY-203 might split into "create exception record" and "notify Ops queue via email" if the team feels it's two units of work).
4. **In-session — estimate:** the dev team estimates story points (often via Planning Poker); the BA does not vote on technical effort but does flag if an estimate seems to ignore a known business constraint.
5. **In-session — prioritize:** re-order the backlog using MoSCoW/WSJF (see next section) with the Product Owner making the final call.
6. **Post-session:** BA updates JIRA with the finalized stories, acceptance criteria, and priority order, and updates the RTM if any story maps to a new/changed FR.

**What a new BA gets wrong:** letting grooming become a status meeting rather than a working session — the entire point is that people are *actively rewriting* stories together, not just listening to a read-out of what's already been decided.

**The grooming session as a flowchart:**

```mermaid
flowchart LR
    A[Pre-session Prep<br/>BA reviews backlog] --> B[Clarify<br/>Restate the why]
    B --> C[Split<br/>Break oversized stories]
    C --> D[Estimate<br/>Planning Poker]
    D --> E[Prioritize<br/>MoSCoW / WSJF]
    E --> F[Post-session<br/>Update JIRA + RTM]
    F -.Next sprint.-> A
```

---

## 22. MoSCoW Prioritization (and WSJF, the Scaled-Agile Alternative)

**Purpose:** a shared vocabulary for prioritizing scope when there isn't time/budget for everything — critical when reprioritizing a multi-module backlog like Onboarding/Settlement/Reconciliation/Payments together.

| Category | Meaning | Example from this project |
|---|---|---|
| **Must Have** | Legally/contractually non-negotiable, or the project fails without it | KYC/AML checks before onboarding completion |
| **Should Have** | Important but not fatal if delayed one release | Real-time (vs 15-min) reconciliation polling |
| **Could Have** | Nice-to-have, first to be cut under time pressure | Custom Ops dashboard theming |
| **Won't Have (this time)** | Explicitly deferred — written down so it doesn't quietly resurface as scope creep | NACH batch reconciliation automation (Phase 2) |

**What a new BA gets wrong:** letting every stakeholder call their item a "Must Have." Push back with a direct question: "what breaks — legally, financially, or operationally — if this ships one release late?" If nothing breaks, it isn't a Must Have.

**WSJF (Weighted Shortest Job First):** a second prioritization technique, common in larger Scaled Agile (SAFe) fintech environments where multiple teams compete for the same backlog slots and MoSCoW's four buckets aren't granular enough to rank within a bucket.

```
WSJF Score = (Business Value + Time Criticality + Risk Reduction/Opportunity Enablement) ÷ Job Size (Effort)
```
Each factor is typically scored on a relative scale (e.g., Fibonacci: 1, 2, 3, 5, 8, 13) by the team, and items are ranked by score — higher score ships first. A BA's role in WSJF is usually to help quantify "Business Value" and "Time Criticality" credibly (using the same evidence you'd put in a Business Case), since developers are better placed to estimate "Job Size" and the BA/Product Owner best placed to judge urgency and risk.

**When to use which:** MoSCoW is faster and more intuitive for a single team/module (used throughout this guide's case study); WSJF earns its complexity once you have several teams and a genuinely long backlog competing for the same sprint capacity.

**Sample MoSCoW split for the Payments Platform backlog, as a chart:**

```mermaid
pie showData
    title Backlog Items by MoSCoW Category (Payments Platform, Sprint 7 snapshot)
    "Must Have" : 14
    "Should Have" : 9
    "Could Have" : 5
    "Won't Have (this release)" : 4
```

---

## 23. Sprint Planning, Stand-ups, Reviews, Retrospectives

| Ceremony | BA's actual role |
|---|---|
| **Sprint Planning** | Confirms the team fully understands each story's acceptance criteria before commitment; answers "what does the business actually mean by X" questions live |
| **Daily Stand-up** | Reports on requirement-related blockers ("waiting on Risk/Compliance sign-off for FR-02.3"); does NOT report task-by-task engineering status — that's for developers |
| **Sprint Review / Demo** | Validates the demoed increment against the original acceptance criteria in front of the Product Owner/stakeholders — the BA is often the one saying "yes, this matches what we agreed" or "this misses Scenario 2 from the acceptance criteria" |
| **Retrospective** | Contributes process observations (e.g., "3 stories got blocked this sprint because FRD sign-off came in late — let's move Compliance review earlier next sprint") |

**Sample — Retro note the BA might raise:**
> "This sprint, 2 stories were re-opened after UAT because acceptance criteria didn't cover the timeout scenario. Action: BA to add explicit error-handling scenarios to every story's acceptance criteria going forward, not just the happy path."

### 23a. Definition of Ready (DoR) & Definition of Done (DoD) — the Two Checklists That Make All of This Work

Every ceremony above quietly depends on two team-agreed checklists that a new BA needs to know by name, because "is this story ready?" and "is this story actually done?" come up constantly, and guessing the answer is how scope and quality problems start.

- **Definition of Ready (DoR):** the criteria a story must meet *before* it can enter a sprint — this is literally what backlog grooming (Section 21) and Three Amigos (Section 24) exist to achieve. A story without agreed acceptance criteria, without an estimate, or with an unresolved dependency is **not ready**, no matter how urgent it feels.
- **Definition of Done (DoD):** the criteria a story must meet to be considered *complete* — not "code written," but genuinely shippable. This is what the Epic's "Definition of Done" field in Section 19 was already using without formally introducing the concept.

**Sample DoR checklist (BA-relevant items):**
- [ ] User story follows the "As a / I want / So that" format
- [ ] Acceptance criteria written in Given/When/Then, covering at least one edge case
- [ ] Dependencies identified and confirmed available (data, upstream service, design asset)
- [ ] Story estimated by the dev team (story points)
- [ ] No open compliance/Risk question attached to this story

**Sample DoD checklist (BA-relevant items):**
- [ ] Code merged and unit-tested
- [ ] All acceptance criteria demonstrated and verified — not just "looks right"
- [ ] RTM row updated to reflect this story's test case status
- [ ] Product Owner has reviewed the increment against the original ask

**What a new BA gets wrong:** treating DoR/DoD as boilerplate copied from a template instead of a checklist the *whole team* — including you — actively agreed to and enforces. A DoR nobody actually checks against is worse than no DoR, because it creates false confidence that a story was vetted when it wasn't.

---

## 24. Three Amigos Sessions

**Purpose:** a short, focused session — typically time-boxed to 15–60 minutes per story — with exactly three perspectives — **Business** (BA/Product Owner), **Development**, and **QA** — held *before* a story enters a sprint, to kill ambiguity before it becomes a defect.

```
SEQUENCE — Three Amigos Session
   BA/Product           Developer              QA Tester
      |                      |                      |
      |-- Reads story out -->|                      |
      |                      |-- "What if the API
      |                      |    times out here?" ->|
      |<----------------------------- "How would we test that?" 
      |-- Adds timeout scenario to acceptance criteria live -->
      |                      |<-- Confirms buildable |
      |                      |                      |<-- Confirms testable
      |-- Story marked "Ready for Sprint" ---------->|
```

**Same session as a Mermaid chart:**

```mermaid
sequenceDiagram
    participant BA as BA / Product Owner
    participant Dev as Developer
    participant QA as QA Tester
    BA->>Dev: Reads story + acceptance criteria
    BA->>QA: Reads story + acceptance criteria
    Dev->>BA: "What if the API times out here?"
    QA->>BA: "How would we test that?"
    BA->>BA: Adds timeout scenario to acceptance criteria live
    Dev-->>BA: Confirms buildable
    QA-->>BA: Confirms testable
    BA->>Dev: Story marked "Ready for Sprint"
    BA->>QA: Story marked "Ready for Sprint"
```

**What a new BA gets wrong:** skipping this for stories that "seem simple." The stories that skip Three Amigos are disproportionately the ones that bounce back from UAT with a "wait, nobody said what happens if..." defect — this session is cheap insurance against exactly that.

---

### 🔑 Key Takeaways — Part E
- A well-sized Epic maps to roughly 2–4 sprints and one FRD section — not a whole FRD, not one paragraph.
- Child stories get written in **grooming**, as a team conversation — not dictated solo by the BA in advance.
- Acceptance criteria must be concrete Given/When/Then — if you can't picture the exact test case it implies, it isn't specific enough.
- **DoR** gates entry into a sprint; **DoD** gates whether a story counts as truly complete — both are team-agreed, not BA-dictated.
- Three Amigos is cheap insurance — the stories that skip it disproportionately bounce back from UAT with a "nobody said what happens if..." defect.

### 🧠 Active Recall Check — Part E
<details><summary>1. Roughly how many sprints should a well-sized Epic span?</summary>About 2–4 sprints.</details>

<details><summary>2. In backlog grooming, who estimates story points — the BA or the dev team?</summary>The dev team (the BA doesn't vote on technical effort).</details>

<details><summary>3. What does DoR stand for, and what does it gate?</summary>Definition of Ready — the criteria a story must meet before it can enter a sprint.</details>

<details><summary>4. Who are the three roles in a Three Amigos session?</summary>Business (BA/Product Owner), Development, and QA.</details>

---
# PART F — BUILD, TEST & RELEASE

## 25. BA's Role During Development (Query Handling, Change Impact)

While developers build, a BA is NOT idle — this is one of the busiest phases:

- **Fielding requirement clarification queries** — usually via a JIRA comment thread or a dedicated Slack channel, resolved same-day wherever possible so the developer isn't blocked.
- **Running Change Impact Analysis** when a mid-sprint change is requested — a BA traces the proposed change through the RTM to see every FRD/story/test case it touches before agreeing to the change.
- **Sample Change Impact note:**
> "Requested change: increase reconciliation tolerance from ₹1 to ₹5. Impact: touches FR-01.4, story PAY-205, test cases TC-045/TC-046, and requires Finance Lead re-sign-off since it changes a previously agreed business rule. Estimated effect: +1 day (re-test + re-approval), no code re-architecture needed."
- **Updating the RTM and BRD/FRD version history** as approved changes land, so the documentation never drifts out of sync with what's actually being built.

---

## 26. UAT Planning

**Purpose:** define scope, entry/exit criteria, environment, roles, and timeline for User Acceptance Testing — the final business-facing checkpoint before go-live.

**Sample — UAT Plan excerpt:**

> **Scope:** All stories under Epics PAY-200 (Reconciliation) and ONB-100 (Onboarding) delivered in Sprints 7–10.
> **Entry Criteria:** All in-scope stories marked "Dev Complete," SIT (System Integration Testing) passed, test data seeded in UAT environment.
> **Exit Criteria:** 100% of Must Have test cases passed, zero critical/high defects open, Product Owner sign-off obtained.
> **Environment:** UAT-2 (production-like, masked production data).
> **Roles:** BA (test case authoring + coordination), QA Lead (execution oversight), Business users (execute test cases from the user's perspective), Dev team (on standby for defect triage).
> **Timeline:** 2 weeks, with 3 daily defect triage calls per week.

---

## 27. Writing UAT Test Cases (Full Worked Examples)

**Purpose:** the concrete, step-by-step scripts business users execute to prove the system does what the BRD/FRD said it would. **Golden rule:** every acceptance criterion in a user story should produce at least one test case — ideally a positive (happy path) case AND a negative/edge case.

**Sample — UAT Test Case Template (fields used industry-wide):**

| Field | Value |
|---|---|
| Test Case ID | TC-045 |
| Related Requirement | BR-01 / FR-01.2 / Story PAY-203 |
| Test Scenario | Reconciliation break creates exception record when amount difference exceeds tolerance |
| Preconditions | Test transaction exists with gateway status = SUCCESS, ledger status = PENDING, amount difference = ₹10 |
| Test Steps | 1. Wait for 15-min polling cycle to run (or trigger manually in UAT). 2. Query the Ops Exception Queue for the test transaction ID. |
| Test Data | txn_id = TXN00123456, gateway_amount = ₹1010, ledger_amount = ₹1000 |
| Expected Result | Exception record created with `recon_break_flag = TRUE`; record visible in Ops Exception Queue within 15 minutes |
| Actual Result | *(filled in during execution)* |
| Status | Pass / Fail / Blocked |
| Executed By / Date | *(tester name, date)* |
| Defect ID (if failed) | *(linked JIRA bug ID)* |

**Sample — a second test case covering the negative/tolerance-boundary path:**

| Field | Value |
|---|---|
| Test Case ID | TC-046 |
| Test Scenario | Amount difference within ₹1 tolerance auto-resolves instead of creating an exception |
| Test Data | gateway_amount = ₹1000.50, ledger_amount = ₹1000.00 (difference = ₹0.50) |
| Expected Result | Transaction auto-resolves; no exception record created; resolution logged in audit trail |

**Step-by-step, how a BA actually writes a full UAT test suite:**
1. Open the RTM and list every FR/story not yet covered by a test case.
2. For each acceptance criterion (Given/When/Then), write one test case per Given/When branch — that's exactly how Scenario 1 and Scenario 2 from the user story in Section 20 became TC-045 and TC-046 above.
3. Explicitly include boundary/negative data (invalid input, exact threshold values, timeouts) — not just the happy path.
4. Map each test case back to its Test Case ID in the RTM.
5. Walk business users through the test cases before execution day so they understand what "pass" looks like in their own words, not just technical language.

**What a new BA gets wrong:** writing test cases that only check the happy path, or writing "expected result" so vaguely ("system works correctly") that two different testers could disagree on whether it passed.

---

## 28. Defect Triage & Defect Reports

**Purpose:** when a UAT test case fails, a BA doesn't just "log a bug" — they help decide whether it's a genuine build defect, a requirement gap, or a misunderstanding, and prioritize it correctly.

**Sample — Defect Report:**

| Field | Value |
|---|---|
| Defect ID | DEF-089 |
| Related Test Case | TC-045 |
| Summary | Exception record created but `flagged_timestamp` field is blank |
| Severity | Medium (data quality issue, not a functional blocker) |
| Priority | High (blocks audit trail requirement) |
| Steps to Reproduce | Same as TC-045 steps 1–2 |
| Expected vs Actual | Expected: `flagged_timestamp` populated with detection time. Actual: field is NULL. |
| Root Cause (post-triage) | Requirement gap — FR-01.2 didn't explicitly specify the timestamp source; dev used a different field by assumption |
| Resolution | FRD updated (FR-01.2 revised to specify `flagged_timestamp = system UTC time at detection`); dev fix deployed; TC-045 re-executed and passed |

**Defect Triage sequence a BA runs (usually a daily call during UAT):**
```
QA/Tester reports failure --> BA reviews against FRD/acceptance criteria
        |                              |
        |                  Is this what the FRD actually says?
        |                    /                        \
             YES (build defect)              NO (requirement gap or ambiguity)
                    |                                    |
         Log as Dev bug, assign            BA updates FRD/story, gets
         severity/priority, route          Product Owner re-sign-off,
         to Dev team                       re-scopes as a Change Request
                                            if it affects committed scope
```

**Same decision logic as a flowchart:**

```mermaid
flowchart TD
    A[QA reports UAT failure] --> B{Does the FRD/acceptance<br/>criteria actually specify this?}
    B -->|Yes — spec exists, build missed it| C[Log as Build Defect]
    C --> D[Assign severity + priority]
    D --> E[Route to Dev team for fix]
    B -->|No — never specified| F[Requirement Gap]
    F --> G[BA updates FRD/story]
    G --> H[Product Owner re-sign-off]
    H --> I{Affects committed<br/>sprint scope?}
    I -->|Yes| J[Raise as Change Request]
    I -->|No| K[Add to backlog for next grooming]
```

**What a new BA gets wrong:** assuming every UAT failure is automatically "Engineering's fault." A large share of UAT defects (as in DEF-089 above) trace back to an underspecified requirement — the BA has to be honest about that, not defensive, because that honesty is what actually improves the next FRD.

---

## 29. Regression / Smoke / Sanity Testing Coordination

A BA doesn't execute these tests personally but coordinates scope and confirms sign-off:

- **Smoke Testing:** quick check that the build is stable enough to even start testing ("does the app launch, can I log in?"). BA confirms critical-path smoke cases are defined before every UAT cycle begins.
- **Sanity Testing:** narrow, targeted check that a specific bug fix didn't break the specific feature it touched. BA confirms the fixed defect's original test case is included.
- **Regression Testing:** broader check that new changes haven't broken previously working functionality. BA maintains/prioritizes the regression test case list — typically the Must Have test cases from every prior release get re-run.

---

## 30. Sign-off & Go-Live Checklist

**Sample — Go-Live Readiness Checklist a BA owns and circulates:**

- [ ] All Must Have RTM rows marked "Passed"
- [ ] Zero open Critical/High defects (Medium/Low defects logged with agreed workaround or deferred with Product Owner sign-off)
- [ ] UAT sign-off obtained in writing from Product Owner and Business Sponsor
- [ ] Risk/Compliance sign-off obtained for any KYC/AML/PCI-DSS-related requirement
- [ ] Rollback plan documented and reviewed with Engineering
- [ ] KPI dashboard (Power BI) live and validated against real data
- [ ] Hypercare support roster and escalation path published to all stakeholders
- [ ] Final BRD/FRD/RTM versions archived in Confluence as the "as-built" record

---
# PART G — POST-GO-LIVE & GOVERNANCE

## 31. Hypercare & KPI Dashboards (Power BI)

**Purpose:** the 2–4 week window immediately after go-live where the BA and team monitor closely and respond fast, before handing off to steady-state support.

**Sample — KPI Dashboard metrics a BA defines and validates (Power BI):**

| KPI | Definition | Target | Data Source |
|---|---|---|---|
| SLA Compliance % | % of transactions settled within agreed SLA window | ≥ 98% | Settlement Engine logs |
| Reconciliation Break Rate | % of transactions flagged as breaks | ≤ 2% | Reconciliation Engine |
| Avg. Break Resolution Time | Time from flag to resolution | < 4 hours | Ops Exception Queue |
| Critical Defect Count (Hypercare) | Open critical/high defects post go-live | 0 | JIRA |

**BA's hypercare role, concretely:** daily dashboard review, triaging any new production issue the same way a UAT defect was triaged (build defect vs requirement gap), and running a lightweight daily hypercare stand-up with Ops/Engineering/Risk until metrics stabilize.

### 31a. A Configuration Detail That Actually Matters: Continuous vs. Categorical Axis

When you define a trendline chart requirement for the settlement dashboard (e.g., "daily SLA compliance % over time"), specify that the date axis must be **continuous, not categorical** — this single setting is the difference between a chart that surfaces a real problem and one that quietly hides it:

- A **categorical** axis treats each date as a text label and places points side by side with equal spacing — if a day has zero data (a gap, an outage, a missed load), Power BI silently skips it and the line looks unbroken. A genuine anomaly can hide in plain sight.
- A **continuous** axis treats dates as points on a true numeric/chronological scale — gaps show up as gaps, and day-over-day spacing reflects the actual time elapsed, which is exactly what makes a sudden SLA drop or a missing day of data visually obvious the moment you look at the dashboard.

**What a new BA gets wrong:** treating "which axis type" as a Power BI developer's implementation detail rather than a requirement. If the BA doesn't specify continuous axis explicitly in the FRD/dashboard requirement, Power BI's default behavior (which varies by field type and how the date hierarchy is set up) can silently produce the misleading categorical version instead — and the first time anyone notices is when a real SLA breach was sitting in the data, invisible on the chart.

---

## 32. Change Request (CR) Management

**Purpose:** any scope change *after* the BRD/FRD are baselined must go through a formal CR — this is what protects the project from silent scope creep while still allowing legitimate business changes.

**Sample — Change Request Form:**

> **CR ID:** CR-014
> **Requested By:** Finance Lead
> **Description:** Increase settlement tolerance threshold from ₹1 to ₹5 to reduce Ops exception volume.
> **Business Justification:** Post-go-live data shows 40% of flagged exceptions are sub-₹5 rounding differences, consuming Ops time disproportionate to actual risk.
> **Impact Analysis (BA-authored):** Touches FR-01.4, Story PAY-205, Test Cases TC-045/TC-046 (re-execution required); no architectural change; +1 sprint day for re-test and re-sign-off.
> **Approval:** Product Owner ✅, Risk/Compliance ✅ (confirms ₹5 tolerance still within audit policy), Finance Lead ✅
> **Status:** Approved — scheduled for Sprint 14.

**What a new BA gets wrong:** implementing a stakeholder's "quick change" request informally without running it through the CR process — even a seemingly tiny change (like this tolerance threshold) can have compliance implications that only surface if you force the formal Impact Analysis step.

---

## 33. Scenario Playbook — How a BA Handles 15 Real Situations

| # | Scenario | What a BA actually does |
|---|---|---|
| 1 | Two stakeholders give contradictory requirements | Document both positions with their business rationale, escalate to the RACI "Accountable" owner for a documented decision — never silently pick one side yourself |
| 2 | A developer says a requirement is "not feasible" | Ask what specifically is infeasible (performance? data availability? third-party constraint?), then work with the dev lead to find an alternative that still meets the business objective, and update the FRD with the agreed alternative |
| 3 | A stakeholder asks for a change mid-sprint | Run a Change Impact Analysis first; if it doesn't affect the current sprint's committed stories, log it for next sprint's backlog grooming; if it does, escalate to Product Owner for a sprint-scope decision |
| 4 | UAT uncovers the requirement itself was wrong | Don't defend the original FRD — update it, get re-sign-off, and treat it as a genuine finding, not a personal failure |
| 5 | Scope creep is happening slowly across several small "just one more thing" requests | Track every "small" addition against the SoW's Out-of-Scope list; once a pattern is visible, bring a consolidated list to the Product Owner as a formal CR discussion rather than absorbing each one silently |
| 6 | A Compliance stakeholder blocks go-live at the last minute | Treat it as valid by default (regulatory risk outweighs schedule risk in BFSI); document the specific concern, run a fast-turnaround Impact Analysis, and communicate the revised timeline transparently to all stakeholders |
| 7 | A workshop goes off-topic / stakeholders argue | Redirect to the single decision the meeting needs to reach; park unrelated topics in a visible "parking lot" list for a separate session |
| 8 | Two departments each think the other owns a requirement | This is exactly what the RACI matrix should have prevented — pull it up live in the meeting and resolve the "A" (Accountable) ambiguity on the spot |
| 9 | A defect is found post-go-live that maps to a Must Have requirement | Treat as a production incident: log as Critical, initiate hypercare triage immediately, and communicate status to the Business Sponsor directly, not just Engineering |
| 10 | Engineering wants to start building before the FRD is finalized | Push back diplomatically — offer to fast-track sign-off on the specific FRD sections needed for the next sprint rather than blocking on the entire document, but never let build start on an unsigned business rule |
| 11 | A new stakeholder appears mid-project and disagrees with an already-agreed requirement | Add them to the Stakeholder Register going forward, but don't reopen an already-signed decision without going through the formal CR process — otherwise every late-arriving stakeholder can indefinitely re-litigate the project |
| 12 | Story estimates keep being wildly wrong | Raise it in the retrospective as a process issue — likely cause is under-specified acceptance criteria; propose mandatory Three Amigos sessions for any story over a certain estimate |
| 13 | A regulatory rule changes mid-project (e.g., new RBI guideline) | Treat this as a new Must Have CR regardless of current sprint capacity — regulatory compliance requirements override normal prioritization |
| 14 | Business wants a report Power BI can't produce with existing data | Trace the gap back to the Data Dictionary/S2T mapping — is the data even captured today? If not, this becomes a new requirement (possibly a new Epic) for a future release, not a same-day dashboard fix |
| 15 | A stakeholder wants to skip UAT to hit a deadline | Explain the risk in business terms (unvalidated requirements shipping to production, regulatory audit exposure), offer a reduced-but-risk-based UAT scope (Must Have test cases only) as a compromise rather than skipping entirely |

---
# PART H — REFERENCE

## 33a. How This Guide Maps to BABOK v3 (For CBAP/CCBA/ECBA Study)

Everything in this guide is practitioner-first — real documents, real sequence. If you're also studying toward an IIBA certification (ECBA, CCBA, or CBAP), it helps to know how these sections map onto BABOK v3's six official Knowledge Areas, since that's the vocabulary the exam uses even though this guide teaches the same skills through real artifacts instead of abstract task lists.

| BABOK v3 Knowledge Area | What It Covers | Where It Shows Up in This Guide |
|---|---|---|
| Business Analysis Planning & Monitoring | Planning how BA work will be governed and measured on this initiative | Section 5 (Kickoff), Section 6–7 (Stakeholder Register, RACI) |
| Elicitation & Collaboration | Getting information from stakeholders and confirming it's understood correctly | Section 9 (Elicitation Techniques), Section 24 (Three Amigos) |
| Requirements Life Cycle Management | Tracing, prioritizing, and maintaining requirements through change | Section 18 (RTM), Section 21 (Grooming), Section 32 (Change Requests) |
| Strategy Analysis | Defining the future state and the business need driving a change | Section 11 (Gap Analysis), Week 1 of the Case Study (Business Case) |
| Requirements Analysis & Design Definition (RADD) | Structuring and specifying requirements into a design-ready form | Section 14–17 (BRD, SRS, FRD/FSD, UML), Section 19–20 (Epics, Stories) |
| Solution Evaluation | Assessing whether the delivered solution actually achieves the business value intended | Section 30 (Go-Live Checklist), Section 31 (Hypercare & KPI Dashboards) |

**Why this matters practically, not just for the exam:** BABOK deliberately does *not* mandate a fixed order for these six areas — real BA work moves between them constantly (you're often doing Strategy Analysis and Elicitation in the same week). This guide's week-by-week case study (Part I) is what that non-linear movement actually looks like in practice, with the BABOK KA it corresponds to visible in the table above.

**Two knowledge areas worth a concrete example each, since they're easy to under-rate:**

- **Elicitation & Collaboration** isn't just "ask questions in a meeting" — it formally includes *confirming* elicitation results with stakeholders afterward (a follow-up summary they explicitly sign off on, not just meeting notes you assume are correct). A **JAD (Joint Application Design) workshop** — Section 9's structured multi-stakeholder session — is the textbook BABOK example of this KA in action: it elicits *and* collaboratively confirms understanding in the same session, rather than eliciting once and hoping the write-up matches what everyone meant.
- **Requirements Life Cycle Management** is what the RTM (Section 18) exists to prove, concretely: every business need maps to a specific system design element *and* a specific test case ID — e.g., a security requirement traced to test case `TC-SEC-101`, not just "yes, we tested security." A reviewer should be able to pick any row of your RTM and follow it end to end without a single gap.

---

## 34. Glossary of Every Term Used in This Guide

| Term | Meaning |
|---|---|
| AML | Anti-Money Laundering — regulatory checks preventing illicit fund movement |
| AS-IS / TO-BE | Current state / desired future state of a process |
| BDD | Behaviour-Driven Development — writing requirements as Given/When/Then scenarios |
| BPMN | Business Process Model and Notation — standard for drawing process flows |
| BRD | Business Requirements Document |
| DoD | Definition of Done — team-agreed criteria for a story to count as complete (see Section 23a) |
| DoR | Definition of Ready — team-agreed criteria for a story to enter a sprint (see Section 23a) |
| Epic | A large body of Agile work spanning multiple sprints, broken into stories |
| FRD/FSD | Functional Requirements Document / Functional Specification Document |
| Gap Analysis | Formal comparison of AS-IS vs TO-BE across process/people/tech/data |
| JAD | Joint Application Design — a structured multi-stakeholder requirements workshop |
| KPI | Key Performance Indicator |
| KYC | Know Your Customer — identity verification during onboarding |
| MoSCoW | Must/Should/Could/Won't Have prioritization framework |
| NACH | National Automated Clearing House — batch-based recurring debit rail (India) |
| PCI-DSS | Payment Card Industry Data Security Standard |
| Product Owner | The role accountable for backlog priority and final scope decisions — the "A" on most delivery RACI rows |
| RACI | Responsible/Accountable/Consulted/Informed matrix |
| Reconciliation | Matching internal ledger records against external (gateway/bank) records |
| RTM | Requirements Traceability Matrix |
| S2T Mapping | Source-to-Target data mapping between two systems |
| Scrum Master | The role that facilitates Agile ceremonies and removes team blockers — distinct from the BA, though a small team sometimes blends the two |
| Settlement | Transfer of reconciled funds to a merchant/customer account |
| SIT | System Integration Testing |
| SoW | Statement of Work |
| Sprint | A fixed, short delivery cycle (commonly 2 weeks) in which a set of committed stories is built, tested, and reviewed |
| SRS | Software Requirements Specification |
| Story Points | A relative, team-estimated measure of a story's size/complexity/effort — not a time unit |
| Three Amigos | Business + Development + QA session to clarify a story before sprint |
| UAT | User Acceptance Testing |
| UPI | Unified Payments Interface — India's real-time payment rail |
| Velocity | The average number of story points a team completes per sprint — used to forecast how much backlog fits in future sprints |
| WSJF | Weighted Shortest Job First — a Scaled Agile (SAFe) prioritization formula (see Section 22) |

---

## 35. Self-Check: Am I Ready? (Checklist + How AI Tools Fit In, 2026)

**Before calling yourself "project-ready," confirm you can, without looking anything up:**
- [ ] Explain the difference between a BRD, SRS, and FRD to a new hire in under 2 minutes
- [ ] Draw a Stakeholder Register and RACI matrix from a one-paragraph project description
- [ ] Write a user story with BDD acceptance criteria covering both a happy path AND an edge case
- [ ] Run a backlog grooming session end-to-end (clarify → split → estimate → prioritize)
- [ ] Write 2 UAT test cases directly from a single acceptance criterion
- [ ] Triage a UAT defect and correctly decide "build defect" vs "requirement gap"
- [ ] Explain why a Gap Analysis has to precede a BRD's business need section
- [ ] Draw a simple sequence diagram showing 3–4 systems/actors interacting
- [ ] Fill out a Change Request form with a real Impact Analysis, not just a description
- [ ] Explain, in one sentence, why Compliance/Risk sign-off can override a delivery deadline in BFSI/Fintech
- [ ] Explain the difference between Definition of Ready and Definition of Done without looking it up
- [ ] Name which BABOK v3 Knowledge Area a given real-world task belongs to (e.g., "writing an RTM" → Requirements Life Cycle Management)

**How AI tools change the job in 2026 — without changing the BA's accountability:**
- Tools like Microsoft Copilot are now routinely used to produce first drafts of user stories from a BRD paragraph, generate BDD acceptance criteria scaffolding, and summarize long stakeholder meetings into structured minutes.
- This does **not** remove the BA's core job — it removes the blank-page problem. The BA still owns: validating the AI-drafted requirement against what stakeholders actually said, catching missing edge cases (AI drafts skew toward happy-path by default, same failure mode as a rushed human BA), and being the accountable signature on the final BRD/FRD.
- **Practical rule for a new BA:** use AI to draft, never to decide. If you can't explain *why* a generated acceptance criterion is correct, you're not ready to put your name on it.

---

*End of Field Guide. Recommended study pace: 3–4 sections per day over ~10 days, replicating each sample document (Stakeholder Register, RACI, Gap Analysis, BRD, FRD, Epic, User Story, UAT test cases, Defect Report, Change Request) in your own blank template before moving to the next section.*

---

# PART I — FULL PROJECT WALKTHROUGH: A NARRATIVE CASE STUDY (WEEK BY WEEK)

Everything above taught you *what* each document/ceremony is. This part shows you *how it all connects on one real project, in sequence* — including how a BA actually assigns work to different teams, what gets said in meetings, and which document gets written the moment a decision is made. Follow this like a diary.

**The project:** *"Velocity Check" — a real-time fraud rule module for the Payments Platform.* Business problem: Finance/Risk has noticed a spike in low-value, high-frequency fraudulent transactions ("card testing" attacks) that current fraud checks don't catch because they only look at single-transaction value, not transaction *velocity* (how many transactions in how short a time). Timeline: 6 sprints (~12 weeks). Team: 1 BA (you), 1 Product Owner, 4 developers, 2 QA, 1 Risk/Compliance officer, 1 Data Analyst, 1 UX designer (minor role — mostly an Ops-facing alert screen).

**The full 12 weeks as a timeline chart:**

```mermaid
gantt
    dateFormat  YYYY-MM-DD
    title Velocity Check Project — 12-Week Timeline
    axisFormat %e %b
    section Framing
    Week 1 - Intake & Data Validation      :w1, 2026-01-05, 5d
    Week 2 - Stakeholders, RACI, Tasking   :w2, after w1, 5d
    section Requirements
    Week 3 - Elicitation Workshop & AS-IS  :w3, after w2, 5d
    Week 4 - BRD, Gap Analysis, Grooming   :w4, after w3, 5d
    Week 5 - Three Amigos & FRD Detail     :w5, after w4, 5d
    section Build
    Week 6-8 - Sprint Build & Query Handling :w6, after w5, 15d
    section Test
    Week 9-10 - UAT Execution & Triage     :w9, after w6, 10d
    section Release
    Week 11-12 - Sign-off, Go-Live, Hypercare :w11, after w9, 10d
```

---

### WEEK 1 — Intake & Framing

**What happens:** The Product Owner forwards you a two-line Slack message from the Risk officer: *"We're seeing weird spikes of ₹10–₹50 transactions failing in bursts. Might be card testing. Can we get a rule to catch this?"* That's it. That's the entire brief. Turning that into a project is your first job.

**Your approach, step by step:**
1. You do **not** start writing a BRD from a two-line message. You first pull data yourself — this is where your SQL/Python skill is the entry point to the whole project, not a side skill.
2. You write a SQL query against the transaction log for the last 30 days, grouping by card/account ID and counting transactions within rolling 60-second windows, to actually see if the pattern the Risk officer *felt* is real and how big it is.
3. You find: 340 accounts had 5+ sub-₹50 transactions within 60 seconds in the last 30 days, and 78% of those were later reversed/disputed — strong evidence this is real and worth solving.
4. You schedule a 30-minute **Problem Framing meeting** with the Risk officer, Product Owner, and Data Analyst — not a big workshop yet, just enough people to confirm the problem is real and worth a project.

**Meeting discussion (condensed):**
> **You (BA):** "I pulled the last 30 days — 340 accounts show 5+ small transactions within a 60-second window, 78% later disputed. Is that the pattern you meant?"
> **Risk Officer:** "Yes, exactly that. We need a rule that flags this in real time, before settlement, not after we see the dispute."
> **Product Owner:** "Can we scope this as its own mini-project rather than folding it into the main Settlement epic?"
> **You:** "Yes — I'll draft a one-page Business Case with the data I just showed you, and a rough scope, by tomorrow."

**Document written this week — Business Case (one-pager):**

> **Problem:** 340 accounts exhibited high-frequency, low-value transaction bursts in the last 30 days consistent with card-testing fraud; 78% resulted in disputes, an estimated ₹4.2L in dispute-handling cost this quarter alone.
> **Proposed Solution:** Real-time velocity-check rule: flag any account with ≥5 transactions under ₹50 within a 60-second window, before settlement.
> **Expected Benefit:** Estimated 70%+ reduction in this fraud pattern based on industry-standard velocity thresholds; reduced dispute-handling cost.
> **Rough Effort:** ~4–6 sprints, 1 BA, 4 devs, 2 QA.
> **Decision Needed:** Approve as a standalone mini-project under the Fraud Epic.
>
> **Approved by Product Owner — proceed to Stakeholder Register + Kickoff.**

**Why this approach, not straight to a workshop:** a BA who runs a full stakeholder workshop before validating the problem with data wastes 8 people's time if the "spike" turns out to be a reporting glitch. Data-first framing is a deliberate sequencing choice, not a shortcut.

---

### WEEK 2 — Stakeholders, RACI, and Task Assignment

**What happens:** With the Business Case approved, you formally open the mini-project.

1. You build the **Stakeholder Register** (Risk Officer, Product Owner, Dev Lead, QA Lead, Data Analyst, UX Designer, Ops Manager — the last one because Ops will need to review flagged accounts).
2. You build the **RACI matrix** for this specific module.
3. **This is the week you actually assign work** — and this is the part new BAs are most unsure about, so here's exactly how it's done:

**How a BA "assigns" tasks (you don't manage people — you assign *documentation and clarification ownership*, the PM/Dev Lead assigns *build* tasks):**

| Task | Who you assign it to | How you communicate it |
|---|---|---|
| Confirm exact velocity thresholds (5 txns/60 sec — final or adjustable?) | Risk Officer | Direct 15-min call + follow-up email confirming the number in writing |
| Confirm data availability (is `txn_timestamp` granular to the second in the current DB?) | Data Analyst | JIRA task with a due date, tagged in the ticket description |
| Estimate build effort for a real-time rule engine change | Dev Lead | Shared in backlog grooming (Week 4), not asked 1:1 — needs the whole dev team's input |
| Design the Ops alert screen (how a flagged account appears to Ops) | UX Designer | Kickoff meeting + a Figma review scheduled for Week 5 |
| Confirm UAT resourcing (who executes test cases from the business side?) | QA Lead + Ops Manager | Included in the UAT Plan draft, confirmed in Week 8 |

Notice: you never say "go build X." You say "I need this decision/input by this date, here's why" — that's the actual mechanism of how a BA "assigns" work; the PM/Dev Lead is the one assigning code tickets.

**Document written this week — RACI (excerpt):**

| Activity | BA | Risk Officer | Dev Lead | QA Lead |
|---|---|---|---|---|
| Define velocity threshold rule | R | A | C | I |
| Build rule engine logic | I | C | A/R | I |
| Write UAT test cases | R | C | I | A |

---

### WEEK 3 — Elicitation Workshop & AS-IS Mapping

**What happens:** Now you run the full workshop — because now you have a validated problem, a stakeholder list, and specific open questions to resolve, not a vague topic.

**Workshop agenda you send 48 hours ahead:**
> 1. Confirm AS-IS: how does the current fraud check work today (no velocity logic)? (10 min)
> 2. Decide: exact velocity threshold and time window (15 min)
> 3. Decide: what happens to a flagged transaction — hard block, or flag + hold for review? (15 min)
> 4. Decide: does this apply to all payment methods (UPI, card) or card only? (10 min)

**Meeting discussion (condensed, showing how a BA drives a decision instead of just taking notes):**
> **Dev Lead:** "Technically, blocking in real-time is harder than flag-and-hold — it needs a synchronous check before the gateway responds."
> **Risk Officer:** "We want a hard block, that's the whole point."
> **You (BA):** "Let's separate the *business* requirement from the *build* difficulty for a second — Risk, is a 2-second delay in transaction response acceptable if it lets us block in real time, or does the block need to be truly zero added latency?"
> **Risk Officer:** "2 seconds is fine, our current gateway timeout is 5."
> **You (BA):** "Great — so the decision is: real-time block, up to 2 seconds added latency, at the gateway synchronous check point. I'll capture that as BR-01 today."

This is the core BA skill on display: turning a values disagreement ("we want it now" vs. "that's hard") into one concrete, testable requirement everyone actually signed up for.

**Document written this week — AS-IS Process Map (text form):**
```
LANE: Gateway              LANE: Current Fraud Check (AS-IS)          LANE: Risk Ops
   |                              |                                        |
[Txn Submitted] ---------> [Check single-txn amount
                             against static rules]
                                   |--Pass--> [Approve, settle]
                                   |--Fail--> [Decline]
                             (NO velocity/frequency check exists today)
                                                                    [Ops only sees fraud
                                                                     AFTER a dispute is
                                                                     filed by customer]
```
This diagram is what makes the gap ("no velocity check exists, Ops only reacts after a dispute") undeniable to everyone in the room — a picture wins the argument a paragraph can't.

---

### WEEK 4 — BRD, Gap Analysis, and Backlog Grooming

**What happens:** With the decisions from Week 3 locked, you write the **BRD** and **Gap Analysis**, then bring the Epic to backlog grooming for the dev team to break down and estimate.

**Document written — BRD excerpt:**
> **BR-01:** The system shall block, in real time (within a maximum 2-second added latency), any transaction from an account exhibiting ≥5 transactions under ₹50 within a rolling 60-second window.
> **BR-02:** All blocked transactions shall be logged to a Risk Ops review queue for manual disposition (release or confirm-fraud) within 1 business hour.
> **Priority:** Must Have. **Owner:** Risk Officer.

**Backlog Grooming session (Week 4, second half) — this is where the Epic becomes real stories:**
> **You (BA):** "Here's Epic FRD-300, Velocity Check Rule. BR-01 and BR-02, translated into FR-01 through FR-04 in the FRD draft I shared yesterday."
> **Dev Lead:** "This is at least two stories — the real-time detection logic, and the Ops review queue, they touch completely different services."
> **You (BA):** "Agreed — let's split: Story 1, 'Detect and block velocity-fraud transactions in real time.' Story 2, 'Create Ops review queue entry for blocked transactions.' Story 2 also needs the UX Figma screen — should that be its own story or a sub-task?"
> **UX Designer:** "Own story — I need at least 3 days for the Ops queue screen design + review."
> **Dev Team (Planning Poker):** Story 1 = 8 points, Story 2 = 5 points, Story 3 (UX) = 3 points.
> **Product Owner:** "Must Have, all three — into Sprint 1 of this mini-project."

**Why this sequence (BRD → Epic → Grooming, not BRD → straight to coding):** grooming is where the *team*, not just the BA, discovers the real shape of the work (splitting into 3 stories instead of 1) — skipping it would mean the BA guesses story boundaries alone, usually wrong.

---

### WEEK 5 — Three Amigos, FRD Detail, and UX Review

**What happens:** Before Story 1 enters Sprint 1, you run a **Three Amigos session** — this is where the FRD gets its real teeth (the error-handling detail from Section 16/24 above).

**Three Amigos discussion (condensed):**
> **QA Tester:** "What happens if the velocity check service itself times out — do we fail open (allow the transaction) or fail closed (block it)?"
> **You (BA):** *(realizes this was never decided)* "Good catch — that's not in the FRD yet. Let me get Risk's answer before this story is marked ready."
> *(You message the Risk Officer, who replies within the hour: "Fail closed — never let a check-failure become a fraud loophole.")*
> **You (BA):** "Updated: FR-01.5 — if the velocity check service does not respond within 2 seconds, the transaction shall be blocked by default (fail-closed) and logged for Ops review."
> **Dev Lead:** "That's buildable and clear now. Story's ready."

This single exchange is the textbook example of why Three Amigos exists — a scenario nobody thought to ask about in the big workshop got caught in a 20-minute focused session, *before* it became a production incident.

**Document updated — FRD (new clause added on the spot):**
> **FR-01.5 (Error Handling):** If the velocity-check service does not respond within 2 seconds, the transaction is blocked by default (fail-closed) and logged to the Ops review queue with reason code `VELOCITY_CHECK_TIMEOUT`.

**Same week — UX review:** you sit with the UX Designer and Risk Officer reviewing the Ops queue Figma screen, checking it against FR-02 (what fields Ops needs to see to make a release/confirm-fraud decision) — you're not judging visual design, you're judging *functional completeness* of the screen.

---

### WEEK 6–8 — Build, Query Handling, and UAT Prep

**What happens during the build sprints:**
- You answer 2–4 JIRA clarification comments per day (e.g., "does the 60-second window reset after a block, or keep counting?" → you check with Risk, update FR-01, reply same day).
- Week 7: a **mid-sprint change request** arrives — Risk wants the threshold configurable (not hardcoded at 5/60 sec) so it can be tuned without a code release. You run a **Change Impact Analysis**: touches FR-01, adds a new admin-config story, +3 story points, no timeline impact since it fits current sprint capacity. Product Owner approves; you log it as CR-002 and add the new story to the backlog (not silently swap into the current sprint without discussion).
- Week 8: you draft the **UAT Plan** and start writing **UAT test cases** — including the fail-closed timeout scenario from Week 5's Three Amigos session, which becomes its own dedicated test case (this is exactly why that detail had to be captured in the FRD, not just said out loud in the meeting).

**Sample UAT test case born directly from the Week 5 discussion:**

| Field | Value |
|---|---|
| Test Case ID | TC-VEL-07 |
| Related Requirement | FR-01.5 |
| Test Scenario | Velocity check service timeout results in fail-closed block |
| Test Data | Simulate service delay > 2 seconds on a test transaction |
| Expected Result | Transaction blocked; Ops queue entry created with reason code `VELOCITY_CHECK_TIMEOUT` |

---

### WEEK 9–10 — UAT Execution & Defect Triage

**What happens:** Business users (Risk Ops team) execute the test cases you wrote. One fails:

> **Ops Tester:** "TC-VEL-03 failed — the block happened, but the Ops queue entry is missing the account ID."
> **You (BA), triaging:** *(checks FR-02)* "FR-02 does list `account_id` as a required field on the queue entry — this is a genuine build defect, not a spec gap."
> **You log DEF-041:** Severity Medium, routed to Dev Lead, linked to TC-VEL-03 and FR-02.

Compare this to Week 5's fail-closed discovery — that was a *requirement gap* (never specified), this is a *build defect* (spec existed, build missed it). Telling these two apart correctly, every time, is what separates a BA who "just files bugs" from one who actually improves the FRD.

---

### WEEK 11–12 — Sign-off, Go-Live, and Hypercare

**What happens:**
- All Must Have RTM rows reach "Passed"; DEF-041 is fixed and re-tested.
- You circulate the **Go-Live Checklist** (Section 30) — Risk/Compliance signs off explicitly because this is a fraud-control feature with audit implications.
- Go-live happens on a Thursday (deliberately mid-week, so the team has 2 full business days to respond to any hypercare issue before the weekend — a scheduling instinct BAs pick up quickly in BFSI work).
- You build a small **Power BI hypercare view**: daily count of velocity-blocks, false-positive rate (Ops-released blocks ÷ total blocks), and `VELOCITY_CHECK_TIMEOUT` occurrences.
- Week 12, hypercare data shows a 3% false-positive rate (acceptable, per the original Business Case's risk tolerance) — you write a one-page closure summary and archive the final BRD/FRD/RTM in Confluence as the "as-built" record.

---

### What This Case Study Actually Teaches You

Notice the *sequence* was never optional: data validation before workshop, workshop before BRD, BRD before grooming, grooming before Three Amigos, Three Amigos before build, build before UAT, UAT before go-live. Almost every real-world BA mistake is a **sequence** mistake — writing a BRD before validating the problem, or letting code start before Three Amigos catches the fail-closed/fail-open question. Learn the order in this case study as carefully as you learn the documents themselves.

---
